<template>
  <div>
    <h3>Member</h3>
  </div>
</template>
<script>
export default {
  data () {
    return {
    };
  }
}
</script>
<style lang="scss" scoped>
</style>